var BootstrapSelect = {
    init: function () {
        $(".m_selectpicker").selectpicker()
    }
};
jQuery(document).ready(function () {
    BootstrapSelect.init()
});